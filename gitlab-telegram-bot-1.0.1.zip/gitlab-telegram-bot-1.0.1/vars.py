token = '5270063342:AAGshKsgciJBJlMtlxMyiKnb6Od5NKVwHBc'
secret_message = 'XXX'
one_post = 'Hi !'
correct_key = 'Everything is fine !'
invalid_key = "I won't talk to you."
stop_bot = 'Ok, bye.'
message = "*{0} pushed new tag: '{1}' at project: '{2}' default_branch: '{3}' \n{4}/tree/{1}*"
